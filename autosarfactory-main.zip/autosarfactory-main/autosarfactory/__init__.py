"""
This file is to make sure that the autosarfactory is considered as a package.
"""
from . import autosarfactory
